Der Ordner "Zauberwuerfel" enthält das ausführbare Android Studio Programm. 

Der Ordner "de.thkoeln.joltzen.bachelorarbeit.zauberwuerfel" enthält den Programmcode der Zauberwürfel Applikation.
 
Der Ordner "de.thkoeln.cvogt.android.opengl_utilities" enthält den Programmcode der bereitgestellten Android OpenGL-ES Bibliothek, welcher im 
Rahmen der Bachelorarbeit angepasst wurde.