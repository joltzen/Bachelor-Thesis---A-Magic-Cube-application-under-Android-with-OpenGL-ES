package de.thkoeln.joltzen.bachelorarbeit.zauberwuerfel;


import android.graphics.Bitmap;

import de.thkoeln.cvogt.android.opengl_utilities.GLShapeFactoryCV;


public class GLShapeFactoryJO extends GLShapeFactoryCV {

    /**
     * copy of the makeCube method from GLShapeFactoryCV to create a cube of the GLShapeJO class
     *
     * @param id
     * @param textures
     * @return
     */
    public static GLShapeJO makeCube(String id, Bitmap[] textures) {
        if (textures == null || textures.length != 6) return null;
        float edgeLength = 1.0f;
        float leftFrontUpperCorner_X = -edgeLength / 2.0f;   // set values such that model coordinates (0,0,0) are the center of the cube
        float leftFrontUpperCorner_Y = edgeLength / 2.0f;
        float leftFrontUpperCorner_Z = edgeLength / 2.0f;
        GLShapeJO shape = new GLShapeJO(id, trianglesForTexturedCube(leftFrontUpperCorner_X, leftFrontUpperCorner_Y, leftFrontUpperCorner_Z, edgeLength, textures));
        return shape;
    }

}
