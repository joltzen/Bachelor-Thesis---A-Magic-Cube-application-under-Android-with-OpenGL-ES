package de.thkoeln.joltzen.bachelorarbeit.zauberwuerfel;

import java.util.ArrayList;

public class RubiksCube {

    /**
     * The sub cubes of the Rubik's cube
     */
    private GLShapeJO[] cubes;

    /**
     * The moves of the Rubik's cube
     */
    public ArrayList<Moves> movesList = new ArrayList<>();

    /**
     * Permutation of the rubik's cube
     */
    int[] permutation = new int[27];

    /**
     * Constructor for the Rubik's cube
     *
     * @param cubes
     */
    public RubiksCube(GLShapeJO[] cubes) {
        this.cubes = cubes;
        for (int i = 0; i < 27; i++) {
            permutation[i] = i;
        }
    }

    /**
     * Method to update the permutation of the Rubik's cube and starts the animation for the selected layer
     *
     * @param axis
     * @param layer
     * @param clockwise
     * @param revert
     */
    public void rotateSubCubes(int axis, int layer, boolean clockwise, boolean revert) {
        int[] cubeIndex = null;
        int[] cubeIndexMove = null;
        int moveIndex = 0;

        if (axis == 0) {
            moveIndex = clockwise ? 0 : 1;
            switch (layer) {
                //left layer
                case 0:
                    cubeIndex = new int[]{0, 1, 2, 3, 4, 5, 6, 7, 8};
                    cubeIndexMove = clockwise ? new int[]{6, 3, 0, 7, 4, 1, 8, 5, 2} : new int[]{2, 5, 8, 1, 4, 7, 0, 3, 6};
                    break;
                //middleX layer
                case 1:
                    cubeIndex = new int[]{9, 10, 11, 12, 13, 14, 15, 16, 17};
                    cubeIndexMove = clockwise ? new int[]{15, 12, 9, 16, 13, 10, 17, 14, 11} : new int[]{11, 14, 17, 10, 13, 16, 9, 12, 15};
                    break;
                //right layer
                case 2:
                    cubeIndex = new int[]{18, 19, 20, 21, 22, 23, 24, 25, 26};
                    cubeIndexMove = clockwise ? new int[]{24, 21, 18, 25, 22, 19, 26, 23, 20} : new int[]{20, 23, 26, 19, 22, 25, 18, 21, 24};
                    break;
            }
        }
        if (axis == 1) {
            moveIndex = clockwise ? 2 : 3;
            switch (layer) {
                //bottom layer
                case 0:
                    cubeIndex = new int[]{0, 1, 2, 9, 10, 11, 18, 19, 20};
                    cubeIndexMove = clockwise ? new int[]{2, 11, 20, 1, 10, 19, 0, 9, 18} : new int[]{18, 9, 0, 19, 10, 1, 20, 11, 2};
                    break;
                //middleY layer
                case 1:
                    cubeIndex = new int[]{3, 4, 5, 12, 13, 14, 21, 22, 23};
                    cubeIndexMove = clockwise ? new int[]{5, 14, 23, 4, 13, 22, 3, 12, 21} : new int[]{21, 12, 3, 22, 13, 4, 23, 14, 5};
                    break;
                //top layer
                case 2:
                    cubeIndex = new int[]{6, 7, 8, 15, 16, 17, 24, 25, 26};
                    cubeIndexMove = clockwise ? new int[]{8, 17, 26, 7, 16, 25, 6, 15, 24} : new int[]{24, 15, 6, 25, 16, 7, 26, 17, 8};
                    break;

            }
        }
        if (axis == 2) {
            moveIndex = clockwise ? 4 : 5;
            switch (layer) {
                //front layer
                case 0:
                    cubeIndex = new int[]{2, 5, 8, 11, 14, 17, 20, 23, 26};
                    cubeIndexMove = clockwise ? new int[]{20, 11, 2, 23, 14, 5, 26, 17, 8} : new int[]{8, 17, 26, 5, 14, 23, 2, 11, 20};
                    break;
                //middleZ layer
                case 1:
                    cubeIndex = new int[]{1, 4, 7, 10, 13, 16, 19, 22, 25};
                    cubeIndexMove = clockwise ? new int[]{19, 10, 1, 22, 13, 4, 25, 16, 7} : new int[]{7, 16, 25, 4, 13, 22, 1, 10, 19};
                    break;
                //back layer
                case 2:
                    cubeIndex = new int[]{0, 3, 6, 9, 12, 15, 18, 21, 24};
                    cubeIndexMove = clockwise ? new int[]{18, 9, 0, 21, 12, 3, 24, 15, 6} : new int[]{6, 15, 24, 3, 12, 21, 0, 9, 18};
                    break;
            }
        }

        //if revert is true, the move is reversed. if not, the move is added to the move list
        if (revert) {
            movesList.remove(movesList.size() - 1);
        } else {
            movesList.add(new Moves(axis, layer, clockwise));
        }

        if (cubeIndex != null) {
            for (int ci : cubeIndexMove) {
                GLShapeJO subCube = cubes[permutation[ci]];
                subCube.rotate(moveIndex);
                subCube.animate(axis, clockwise);
            }

            //Update the permutation after the rotation
            int[] pCopy = new int[permutation.length];
            System.arraycopy(permutation, 0, pCopy, 0, permutation.length);
            for (int i = 0; i < cubeIndex.length; i++) {
                permutation[cubeIndex[i]] = pCopy[cubeIndexMove[i]];
            }

        }
    }
}
