package de.thkoeln.joltzen.bachelorarbeit.zauberwuerfel;

import android.animation.ObjectAnimator;
import android.animation.TypeEvaluator;
import android.animation.ValueAnimator;

import de.thkoeln.cvogt.android.opengl_utilities.GLShapeCV;

public class GLAnimatorFactoryJO {

    private static final float[] ZERO_ROTATION = new float[3];

    /**
     * Makes an animator to let the shape make a linear rotation around a axis.
     * Adds the new animator to the animators of the given shape.
     *
     * @param shape           The shape to animate.
     * @param angleToTraverse The rotation angle to traverse.
     * @param axis            The rotation axis.
     * @param duration        The duration of the animation.
     * @param repeatCount     The number of times the animation shall be repeated.
     * @param reverse         true if the animation shall be reversed.
     * @return The newly generated animator.
     */

    public static ObjectAnimator addLinearAnimatorRot(GLShapeCV shape, float angleToTraverse, int axis, int duration, int repeatCount, boolean reverse) {
        EvaluatorLinearTransformer eval = new EvaluatorLinearTransformer();

        float[] rotateAxisLast = new float[3];
        rotateAxisLast[axis] = angleToTraverse;
        ObjectAnimator animator = ObjectAnimator.ofObject(shape, "rotateAnimate", eval, ZERO_ROTATION, rotateAxisLast);
        animator.setDuration(duration);
        animator.setRepeatCount(repeatCount);
        if (reverse)
            animator.setRepeatMode(ValueAnimator.REVERSE);
        shape.addAnimator(animator);
        return animator;
    }


    /**
     * Class that defines a TypeEvaluator for a linear rotation around a axis
     */
    private static class EvaluatorLinearTransformer implements TypeEvaluator<float[]> {
        public float[] evaluate(float f, float[] from, float[] to) {
            float[] currentAngle = new float[from.length];
            for (int i = 0; i < from.length; i++) {
                currentAngle[i] = from[i] * (1 - f) + to[i] * f;
            }
            return currentAngle;
        }
    }

}
