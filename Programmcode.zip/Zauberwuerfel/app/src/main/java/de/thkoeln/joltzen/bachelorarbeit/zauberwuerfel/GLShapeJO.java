
package de.thkoeln.joltzen.bachelorarbeit.zauberwuerfel;


import android.animation.ObjectAnimator;
import android.opengl.Matrix;

import de.thkoeln.cvogt.android.opengl_utilities.GLAnimatorFactoryCV;
import de.thkoeln.cvogt.android.opengl_utilities.GLShapeCV;
import de.thkoeln.cvogt.android.opengl_utilities.GLTriangleCV;

public class GLShapeJO extends GLShapeCV {


    /**
     * Update the rotation matrix based on the rotation angles from the angleRotation array
     */
    private int currentRotationStatus = 0;

    /**
     * Rotation status of the sub cube before it was rotated
     */
    private int preRotationStatus;

    /**
     * Rotation angles for the axes x, y and z
     */
    private final float[][] rotationAngles = {
            {0, 0, 0},
            {0, 90, 0},
            {0, 180, 0},
            {0, 270, 0},

            {0, 0, 90},
            {0, 90, 90},
            {0, 180, 90},
            {0, 270, 90},

            {90, 180, 0},
            {90, 180, 270},
            {90, 180, 180},
            {90, 180, 90},

            {0, 90, 270},
            {0, 180, 270},
            {0, 270, 270},
            {0, 0, 270},

            {0, 90, 180},
            {0, 270, 180},
            {0, 0, 180},
            {0, 180, 180},

            {90, 0, 0},
            {90, 0, 90},
            {90, 0, 180},
            {90, 0, 270},
    };

    /**
     * States for the rotation of the sub cube
     */
    private final int[][] moveStatus = {
            {10, 20, 3, 1, 15, 4},
            {12, 5, 0, 2, 23, 9},
            {22, 8, 1, 3, 6, 13},
            {7, 14, 2, 0, 11, 21},

            {9, 21, 7, 5, 0, 18},
            {1, 16, 4, 6, 20, 8},
            {23, 11, 5, 7, 19, 2},
            {17, 3, 6, 4, 10, 22},

            {2, 18, 9, 11, 5, 14},
            {13, 4, 10, 8, 1, 17},
            {19, 0, 11, 9, 12, 7},
            {6, 15, 8, 10, 16, 3},

            {16, 1, 15, 13, 22, 10},
            {21, 9, 12, 14, 2, 19},
            {3, 17, 13, 15, 8, 20},
            {11, 23, 14, 12, 18, 0},

            {5, 12, 18, 19, 21, 11},
            {14, 7, 19, 18, 9, 23},
            {8, 22, 17, 16, 4, 15},
            {20, 10, 16, 17, 13, 6},

            {0, 19, 21, 23, 14, 5},
            {4, 13, 22, 20, 3, 16},
            {18, 2, 23, 21, 7, 12},
            {15, 6, 20, 22, 17, 1},
    };


    /**
     * Constructor for the GLShapeJO class which creates a sub cube
     *
     * @param shapeId
     * @param textureId
     */
    public GLShapeJO(String shapeId, GLTriangleCV[] textureId) {
        super(shapeId, textureId);
    }

    /**
     * Set the rotation status of the sub cube based on the given move index and the current rotation status of the sub cube
     *
     * @param moveIndex
     */
    public void rotate(int moveIndex) {
        preRotationStatus = currentRotationStatus;
        currentRotationStatus = moveStatus[currentRotationStatus][moveIndex];
    }

    /**
     * The method resets all sub cubes to the initial rotation status
     */
    public void resetCube() {
        currentRotationStatus = 0;
        updateRotate();
    }


    /**
     * Update the rotation matrix based on the rotation angles from the angleRotation array
     */

    public void updateRotate() {
        float[] rotationAngle = rotationAngles[currentRotationStatus];
        float[] rotationMatrix = this.getRotationMatrix();
        Matrix.setIdentityM(rotationMatrix, 0);

        // rotate for each single axis by the new angle
        for (int i = 0; i < 3; i++) {
            float[] axis = new float[3];
            axis[i] = 1;
            Matrix.rotateM(rotationMatrix, 0, rotationAngle[i], axis[0], axis[1], axis[2]);
        }
        this.setRotationMatrix(rotationMatrix);
    }

    /**
     * Setter function to set the animated values. The function is called by the ObjectAnimator inside the GLAnimatorFactoryJO class based on the property name.
     *
     * @param rotationAngle
     * @return
     */
    public GLShapeJO setRotateAnimate(float[] rotationAngle) {
        float[] rotationMatrix = this.getRotationMatrix();
        Matrix.setIdentityM(rotationMatrix, 0);
        float[] start = rotationAngles[preRotationStatus];

        float[] axis = new float[3];
        for (int i = 0; i < axis.length; i++) {
            if (rotationAngle[i] != 0) {
                axis[i] = 1;
                Matrix.rotateM(rotationMatrix, 0, rotationAngle[i], axis[0], axis[1], axis[2]);
                axis[i] = 0;
            }
        }
        for (int i = 0; i < axis.length; i++) {
            axis[i] = 1;
            Matrix.rotateM(rotationMatrix, 0, start[i], axis[0], axis[1], axis[2]);
            axis[i] = 0;
        }

        this.setRotationMatrix(rotationMatrix);
        return this;
    }

    /**
     * Animate the rotation of the layer of the magic cube around a point.
     *
     * @param axis
     * @param clockwise
     */
    public void animate(int axis, boolean clockwise) {
        int duration = 300;

        float[] fromRotationAxis = new float[3];
        float[] toRotationAxis = new float[3];
        fromRotationAxis[axis] = -1;
        toRotationAxis[axis] = 1;

        ObjectAnimator animPath = GLAnimatorFactoryCV.addAnimatorArcPathAroundAxis(this, fromRotationAxis, toRotationAxis, 90f, clockwise, duration, 0);
        addAnimator(animPath);
        animPath.start();

        ObjectAnimator animRot = GLAnimatorFactoryJO.addLinearAnimatorRot(this, clockwise ? -90f : 90f, axis, duration, 0, false);
        addAnimator(animRot);
        animRot.start();

    }
}
