package de.thkoeln.joltzen.bachelorarbeit.zauberwuerfel;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.widget.Button;
import android.widget.LinearLayout;

import java.util.Random;

import de.thkoeln.cvogt.android.opengl_utilities.GLSurfaceViewCV;
import de.thkoeln.cvogt.android.opengl_utilities.GraphicsUtilsCV;
import de.thkoeln.cvogt.android.opengl_utilities.TextureBitmapsCV;

public class MainActivity extends Activity {

    /**
     * The surface view to which the shape is currently attached.
     */
    private GLSurfaceViewCV glSurfaceView;

    /**
     * The registered renderer.
     */
    private GLRendererJO renderer;

    /**
     * previously touched x coordinate
     */
    private float previousX;

    /**
     * previously touched y coordinate
     */
    private float previousY;

    /**
     * Information whether the user has touched the Rubik's cube to rotate it or not
     */
    private boolean rotatingLayers = false;

    /**
     * The textures for the Rubik's cube
     */
    private final Bitmap[] textures = new Bitmap[6];

    /**
     * The sub cubes of the Rubik's cube
     */
    private final GLShapeJO[] cubes = new GLShapeJO[27];

    /**
     * The 3 dimensional array of the sub cubes
     */
    public GLShapeJO[][][] cube = new GLShapeJO[3][3][3];

    /**
     * The 3x3x3 Rubik's cube
     */
    private RubiksCube rubiksCube;

    /**
     * The moves of the Rubik's cube
     */
    private Moves moves;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextureBitmapsCV.init(this);
        renderer = new GLRendererJO();
        glSurfaceView = new GLSurfaceViewCV(this, renderer, false);
        createRubiksCube(glSurfaceView);
        setContentView(glSurfaceView);

        LinearLayout buttonLayout = new LinearLayout(this);

        //Create a button to scramble the cube
        Button scramble = new Button(this);
        scramble.setText(R.string.scramble_action);
        scramble.setTextSize(25);
        scramble.setOnClickListener(v -> {
            // rotate one random layer of the cube
            Random random = new Random();
            rubiksCube.rotateSubCubes(random.nextInt(3), random.nextInt(3), random.nextBoolean(), false);

        });

        //Create a button to undo the moves
        Button undo = new Button(this);
        undo.setText(R.string.undo_action);
        undo.setTextSize(25);
        undo.setOnClickListener(v -> {
            // delete the last move from the list
            if (rubiksCube.movesList.size() > 1) {
                moves = rubiksCube.movesList.get(rubiksCube.movesList.size() - 1);
                rubiksCube.rotateSubCubes(moves.axis, moves.layer, !moves.clockwise, true);
            } else if (rubiksCube.movesList.size() == 1) {
                moves = rubiksCube.movesList.get(0);
                rubiksCube.rotateSubCubes(moves.axis, moves.layer, !moves.clockwise, true);
            }
        });

        //Create a button to reset the cube
        Button reset = new Button(this);
        reset.setText(R.string.reset_action);
        reset.setTextSize(25);
        reset.setOnClickListener(v -> {
            // reset all shapes to their initial position
            for (GLShapeJO subCube : cubes) {
                subCube.resetCube();
            }
            //clear the moves list after reset
            while (rubiksCube.movesList.size() != 0) {
                rubiksCube.movesList.remove(rubiksCube.movesList.size() - 1);
            }
        });

        //Add the buttons to the layout
        buttonLayout.addView(scramble);
        buttonLayout.addView(reset);
        buttonLayout.addView(undo);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        params.height = 150;
        this.addContentView(buttonLayout, params);
    }


    /**
     * Creates the Rubik's cube and adds it to the SurfaceView
     *
     * @param surfaceView
     */
    public void createRubiksCube(GLSurfaceViewCV surfaceView) {
        textures[0] = TextureBitmapsCV.get("red");
        textures[1] = TextureBitmapsCV.get("blue");
        textures[2] = TextureBitmapsCV.get("orange");
        textures[3] = TextureBitmapsCV.get("green");
        textures[4] = TextureBitmapsCV.get("white");
        textures[5] = TextureBitmapsCV.get("yellow");

        // Create 27 individual cubes
        for (int cubeIndex = 0; cubeIndex < 27; cubeIndex++) {
            cubes[cubeIndex] = GLShapeFactoryJO.makeCube(Integer.toString(cubeIndex), textures);
        }

        // Sets the translation for the 27 individual cubes to a 3x3x3 cube and add it to the surfaceView
        int cubeIndex = 0;
        for (int x = 0; x < 3; x++) {
            for (int y = 0; y < 3; y++) {
                for (int z = 0; z < 3; z++) {
                    cube[x][y][z] = cubes[cubeIndex];
                    cube[x][y][z].setTrans(x - 1, y - 1, z - 1);
                    surfaceView.addShape(cube[x][y][z]);
                    cubeIndex++;
                }
            }
        }
        rubiksCube = new RubiksCube(cubes);
    }


    /**
     * This method is called when the user touches the screen.
     *
     * @param event
     * @return
     */
    @Override
    public boolean onTouchEvent(MotionEvent event) {

        // normalized coordinates from the touched x and y positions
        float normalizedX = ((2.0f * event.getX()) / glSurfaceView.getWidth()) - 1.0f;
        float normalizedY = 1.0f - ((2.0f * event.getY()) / glSurfaceView.getHeight() - 0.25f);

        float[] distance = new float[2];
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN: {
                // shoot a ray from the touch point into the scene to get the position of the touched object
                int side = renderer.shootRay(normalizedX, normalizedY);

                //check if the cube is touched and set the start touch position and rotateLayers to true
                rotatingLayers = (side != -1);

                // update the previously touched x and y positions
                previousX = event.getX();
                previousY = event.getY();

            }
            break;

            case MotionEvent.ACTION_MOVE: {
                if (!rotatingLayers) {
                    // distance between the current touch position and the previous touch position
                    float deltaX = event.getX() - previousX;
                    float deltaY = event.getY() - previousY;

                    // calculate the camera view angles
                    renderer.calculateEyeCoordinates((deltaX / glSurfaceView.getWidth()), (deltaY / glSurfaceView.getHeight()));
                    // update the previously touched x and y positions
                    previousX = event.getX();
                    previousY = event.getY();
                }


            }
            break;

            case MotionEvent.ACTION_UP: {
                if (rotatingLayers) {
                    // shoot a ray from the touch point into the scene to get the position of the touched object
                    int side = renderer.shootRay(normalizedX, normalizedY);
                    //calculate the swipe direction
                    distance = new float[]{previousX - event.getX(), previousY - event.getY()};
                    float[] absoluteDistance = {Math.abs(distance[0]), Math.abs(distance[1])};

                    // 0 = right, 1 = left, 2 = top, 3 = bottom, 4 = front, 5 = back
                    switch (side) {
                        case 0:
                            if (absoluteDistance[0] < absoluteDistance[1]) {
                                rubiksCube.rotateSubCubes(2, renderer.layer[0], distance[1] < 0f, false);
                            } else {
                                rubiksCube.rotateSubCubes(1, renderer.layer[1], distance[0] >= 0f, false);
                            }
                            break;
                        case 1:
                            if (absoluteDistance[1] < absoluteDistance[0]) {
                                rubiksCube.rotateSubCubes(1, renderer.layer[1], distance[0] >= 0f, false);
                            } else {
                                rubiksCube.rotateSubCubes(2, renderer.layer[0], distance[1] >= 0f, false);
                            }
                            break;
                        case 2:
                            if (absoluteDistance[1] < absoluteDistance[0]) {
                                rubiksCube.rotateSubCubes(2, renderer.layer[1], distance[0] < 0f, false);
                            } else {
                                rubiksCube.rotateSubCubes(0, renderer.layer[0], distance[1] >= 0f, false);
                            }
                            break;
                        case 3:
                            if (absoluteDistance[1] < absoluteDistance[0]) {
                                rubiksCube.rotateSubCubes(2, renderer.layer[1], distance[0] >= 0f, false);
                            } else {
                                rubiksCube.rotateSubCubes(0, renderer.layer[0], distance[1] >= 0f, false);

                            }
                            break;
                        case 4:
                            if (absoluteDistance[0] < absoluteDistance[1]) {
                                rubiksCube.rotateSubCubes(0, renderer.layer[0], distance[1] >= 0f, false);
                            } else {
                                rubiksCube.rotateSubCubes(1, renderer.layer[1], distance[0] >= 0f, false);
                            }
                            break;
                        case 5:
                            if (absoluteDistance[1] < absoluteDistance[0]) {
                                rubiksCube.rotateSubCubes(1, renderer.layer[1], distance[0] >= 0f, false);
                            } else {
                                rubiksCube.rotateSubCubes(0, renderer.layer[0], distance[1] < 0f, false);
                            }
                            break;

                    }
                }
                rotatingLayers = false;
            }
            break;
        }
        return true;
    }

}


