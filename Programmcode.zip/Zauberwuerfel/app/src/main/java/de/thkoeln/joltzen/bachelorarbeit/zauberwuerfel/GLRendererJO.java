package de.thkoeln.joltzen.bachelorarbeit.zauberwuerfel;

import android.opengl.Matrix;
import android.util.Log;

import java.util.Arrays;

import de.thkoeln.cvogt.android.opengl_utilities.GLRendererCV;
import de.thkoeln.cvogt.android.opengl_utilities.GraphicsUtilsCV;


public class GLRendererJO extends GLRendererCV {

    /**
     * vertical angle value to calculate the new camera position after touching the screen.
     */
    private float vertical;

    /**
     * horizontal angle value to calculate the new camera position after touching the screen.
     */
    private float horizontal;

    /**
     * Layer of the cube that should be rotated
     */
    public int[] layer = new int[2];

    /**
     * Side index of the cube that is the closest to the camera
     */
    private int sideIndex;

    /**
     * Normals of the plane that defines a facing direction.
     */
    private static final float[][] normalizedPlane = {
            {-1.1f, 0.0f, 0.0f},
            {1.1f, 0.0f, 0.0f},
            {0.0f, -1.1f, 0.0f},
            {0.0f, 1.1f, 0.0f},
            {0.0f, 0.0f, 1.1f},
            {0.0f, 0.0f, -1.1f},
    };

    /**
     * Shoots a ray based on the screen coordinates. If the ray hits a cube side, the side and the collision point will be stored.
     * The calculation is based on the following article: http://antongerdelan.net/opengl/raycasting.html
     */
    public int shootRay(float x, float y) {

        //Get the view projection matrix and the projection matrix from the GLRendererCV class
        final float[] projectionMatrix = getProjectionMatrix();
        final float[] viewProjectionMatrix = getViewProjectionMatrix();

        final float[] invertedMatrix = new float[16];

        // create homogeneous clip coordinates which indicates the start point of the ray
        float[] ray_clip = GraphicsUtilsCV.homogeneousCoordsForPoint(new float[]{x, y, -1f});

        // calculate the start point of the ray by transforming the homogeneous coordinates with the inverse projection matrix
        Matrix.invertM(invertedMatrix, 0, projectionMatrix, 0);
        Matrix.multiplyMV(ray_clip, 0, invertedMatrix, 0, ray_clip.clone(), 0);

        // set the direction of the line of sight into the view port
        float[] ray_eye = GraphicsUtilsCV.homogeneousCoordsForVector(new float[]{x, y, -1f});

        // to convert from the view space to the world space, the homogeneous coordinates are transformed with the inverse view projection matrix
        Matrix.invertM(invertedMatrix, 0, viewProjectionMatrix, 0);
        Matrix.multiplyMV(ray_eye, 0, invertedMatrix, 0, ray_eye.clone(), 0);

        float[] ray_world = GraphicsUtilsCV.coordsFromHomogeneous(ray_eye);

        //normalise the vector ray_world because z was set to -1, so the ray needs to be normalised.
        ray_world = GraphicsUtilsCV.getNormalizedCopy(ray_world);

        return getCollision(x, y, ray_world);
    }

    /**
     * The method returns the collision point of the ray and the plane and returns the side index of the touched cube side
     *
     * @param x
     * @param y
     * @param ray_point
     * @return
     */
    private int getCollision(float x, float y, float[] ray_point) {
        // get the current camera positions from the GLRendererCV class
        float[] eyes = new float[]{getEyeX(), getEyeY(), getEyeZ()};

        // initial touched side, -1 means no side is touched
        int side = -1;

        // Find intersection point with the planes
        for (int i = 0; i < normalizedPlane.length; i++) {
            //get the normal of the plane that defines the facing direction
            final float[] planeNorm = normalizedPlane[i];

            // angle between the ray and the plane
            final float dotRayPlane = GraphicsUtilsCV.dotProduct(ray_point, planeNorm);
            // angle between the camera and the plane
            final float dotEyePlane = GraphicsUtilsCV.dotProduct(eyes, planeNorm);

            //distance between the ray origin and the plane
            float distance = -(dotEyePlane - 1f) / dotRayPlane;

            final float[] intersectionPoint = new float[3];
            for (int j = 0; j < 3; j++) {
                intersectionPoint[j] = ray_point[j] * distance + eyes[j];
            }

            //check if the ray points intersect with a object
            for (float v : intersectionPoint) {
                if (v >= 1.0f || v <= -1.0f) {
                    distance = 0;
                    break;
                }
            }

            // store the side of the cube with the shortest distance
            if (distance < 0) {
                //calculate the layer that should be rotated
                getLayers(x, y);
                side = this.sideIndex;
            }
        }
        return side;
    }

    /**
     * Calculates the layer of the cube that should be rotated
     *
     * @param x
     * @param y
     */
    private void getLayers(float x, float y) {
        //get the current camera positions from the GLRendererCV class
        float[] eyes = new float[]{getEyeX(), getEyeY(), getEyeZ()};
        // get the absolute value of the camera position
        float[] absEyes = new float[]{Math.abs(eyes[0]), Math.abs(eyes[1]), Math.abs(eyes[2])};
        // get the index of the maximum value of the camera position
        int greatestEye = greatestValue(absEyes);
        // set the index of the side that is touched
        sideIndex = 2 * greatestEye + (eyes[greatestEye] < 0 ? 1 : 0);
        // normalize the camera position
        float[] normEyes = normaliseEyes(sideIndex, eyes);
        // calculate the layer of the cube that is touched
        /**
         * Touched position normalized by the current camera position
         */
        float[] touchPoint = new float[]{calculateTouchedX(normEyes, x), calculateTouchedY(normEyes, y)};

        if (touchPoint[0] >= 0.3f) {
            layer[0] = sideIndex == 5 || sideIndex == 1 ? 0 : 2;
        } else if (touchPoint[0] < -0.3f) {
            layer[0] = sideIndex == 5 || sideIndex == 1 ? 2 : 0;
        } else {
            layer[0] = 1;
        }

        if (touchPoint[1] >= 0.3f) {
            layer[1] = sideIndex == 3 ? 0 : 2;
        } else if (touchPoint[1] < -0.3f) {
            layer[1] = sideIndex == 3 ? 2 : 0;
        } else {
            layer[1] = 1;
        }

    }

    /**
     * Calculates the x coordinate of the touched point on the cube
     *
     * @param normEyes
     * @param x
     * @return
     */
    private float calculateTouchedX(float[] normEyes, float x) {
        float deltaE = (float) Math.atan(normEyes[0] / normEyes[2]);
        float deltaT = (float) Math.asin(x / 3f);
        if (deltaE < 0) {
            return (deltaE / 0.77f) + ((-deltaE / 0.77f) * 2.5f + 4f) * deltaT;
        } else {
            return (deltaE / 0.77f) - ((-deltaE / 0.77f) * 2.5f - 4f) * deltaT;
        }

    }

    /**
     * Calculates the y coordinate of the touched point on the cube
     * +
     *
     * @param normEyes
     * @param y
     * @return
     */
    private float calculateTouchedY(float[] normEyes, float y) {
        float deltaE = normEyes[1] / normEyes[2];
        float deltaT = (float) Math.asin((y / 3f) * (7.4f / 4f));
        if (deltaE < 0) {
            return (deltaE / 0.77f) + ((-deltaE / 0.77f) * 2.5f + 4f) * deltaT;
        } else {
            return (deltaE / 0.77f) - ((-deltaE / 0.77f) * 2.5f - 4f) * deltaT;
        }

    }

    /**
     * Returns the index of the maximum value of the array
     *
     * @param values
     * @return
     */
    private int greatestValue(float[] values) {
        int greatest = 0;
        for (int i = 0; i < values.length; i++) {
            greatest = values[i] > values[greatest] ? i : greatest;
        }
        return greatest;
    }

    /**
     * Normalizes the camera position
     *
     * @param sideIndex
     * @param eyes
     * @return
     */
    private float[] normaliseEyes(int sideIndex, float[] eyes) {
        float[] normEyes = new float[3];
        int si = sideIndex & 0xE;
        switch (si) {
            case 0:
                normEyes[0] = -eyes[2];
                normEyes[1] = eyes[1];
                normEyes[2] = eyes[0];
                break;
            case 2:
                normEyes[0] = eyes[0];
                normEyes[1] = -eyes[2];
                normEyes[2] = eyes[1];
                break;
            case 4:
                normEyes = eyes;
        }
        if (sideIndex % 2 == 1) {
            for (int i = 0; i < 3; i++) {
                normEyes[i] = -normEyes[i];
            }
        }
        return normEyes;
    }

    /**
     * Calculates the camera position around the SurfaceView and sets the values eyeX, eyeY and eyeZ in the GLRendererCV class.
     * Calculation according to https://www.spieleprogrammierung.net/2010/02/mathematik-der-3d-programmierung-teil-3_18.html
     */
    public void calculateEyeCoordinates(float x, float y) {
        this.vertical += Math.PI * y;
        this.horizontal += Math.PI * x;

        float eyeX = ((float) (-5.0f * Math.cos(vertical) * (Math.sin(horizontal))));
        float eyeY = ((float) (5.0f * Math.sin(vertical)));
        float eyeZ = ((float) (5.0f * Math.cos(vertical) * Math.cos(horizontal)));
        setEyeCoordinates(eyeX, eyeY, eyeZ);
    }
}
