package de.thkoeln.joltzen.bachelorarbeit.zauberwuerfel;

public class Moves {
    /**
     * The axis of the previous action (0 = x, 1 = y, 2 = z)
     */
    public int axis;

    /**
     * The layer of the previous action
     */
    public int layer;

    /**
     * The direction of the previous action (true = clockwise, false = counterclockwise)
     */
    public boolean clockwise;

    /**
     * Constructor for the Moves class which stores the axis, part and direction of the previous done rotation
     *
     * @param axis
     * @param layer
     * @param clockwise
     */
    public Moves(int axis, int layer, boolean clockwise) {
        this.axis = axis;
        this.layer = layer;
        this.clockwise = clockwise;
    }
}
