// This work is provided under GPLv3, the GNU General Public License 3
//   http://www.gnu.org/licenses/gpl-3.0.html

// Prof. Dr. Carsten Vogt
// Technische Hochschule Köln, Germany
// Fakultät für Informations-, Medien- und Elektrotechnik
// carsten.vogt@th-koeln.de
// 27.3.2022

package de.thkoeln.cvogt.android.opengl_utilities;

import android.util.Log;

import java.util.Date;

/**
 * Class with static methods to create a number of 3D objects, i.e. objects of class GLShapeCV,
 * and place them on an GLSurfaceView.
 * <BR>
 * @see GLShapeCV
 * @see GLSurfaceViewCV
 */

public class GLSceneFactory {

    /**
     * Makes and places a number of cubes that lie equidistantly between two points.
     * @param numberOfCubes The number of cubes to be made (must be >1).
     * @param scalingFactor The scaling factor for the cubes (must be >0).
     * @param point1 The first point (must be an array of length 3).
     * @param point2 The second point (must be an array of length 3).
     * @param colors The color(s) of the cubes.
     * @param rotate Rotate the cubes to align their faces?
     * @param animationDuration If > 0 the placement is animated and takes 'animationDuration' seconds.
     * @return The cubes or null if one of the parameters is not valid.
     */

    public static GLShapeCV[] makeCubesInLine(int numberOfCubes, float scalingFactor, float point1[], float point2[], float[][] colors, boolean rotate, int animationDuration) {
        if (point1==null||point1.length!=3||point2==null||point2.length!=3||numberOfCubes<2||scalingFactor<=0) return null;
        GLShapeCV cubes[] = new GLShapeCV[numberOfCubes];
        float[] vector = new float[3];
        vector[0] = point2[0]-point1[0];
        vector[1] = point2[1]-point1[1];
        vector[2] = point2[2]-point1[2];
        float[] y_axis = {0,1,0};
        float[] rotAxis = GraphicsUtilsCV.crossProduct(y_axis,vector);
        float rotAngle = (float) Math.toDegrees(Math.acos(GraphicsUtilsCV.dotProduct(y_axis, GraphicsUtilsCV.getNormalizedCopy(vector))));
        float[][] positions = GraphicsUtilsCV.pointsInLine(point1,point2,numberOfCubes);
        for (int i=0; i<numberOfCubes; i++) {
            cubes[i] = GLShapeFactoryCV.makeCube("Cube"+i, colors);
            if (cubes[i]==null) return null;
            cubes[i].setScale(scalingFactor);
            if (animationDuration>0)
                GLAnimatorFactoryCV.addAnimatorTrans(cubes[i], positions[i], animationDuration, 0);
            else
                cubes[i].setTrans(positions[i]);
            if (rotate)
                cubes[i].setRotation(rotAngle,rotAxis);
        }
        /*
        float[] position = new float[3];
        for (int i=0; i<numberOfCubes; i++) {
            cubes[i] = GLShapeFactoryCV.makeCube("Cube"+i, colors);
            if (cubes[i]==null) return null;
            cubes[i].setScale(scalingFactor);
            if (i<numberOfCubes-1)
                for (int j=0; j<3; j++) position[j] = point1[j]+vector[j]/(numberOfCubes-1)*i;
              else
                position = point2.clone();
            if (animated)
                GLAnimatorFactoryCV.addAnimatorTrans(cubes[i], position, 2000, 0);
              else
                cubes[i].setTrans(position);
            if (rotate) {
                cubes[i].setRotAxis(rotAxis);
                cubes[i].setRotAngle(rotAngle);
            }
        }
        */
        return cubes;
    }

    /**
     * Makes and places a number of spheres that lie equidistantly on a circle.
     * @param numberOfSpheres The number of spheres to be made (must be >1).
     * @param scalingFactor The scaling factor for the spheres (must be >0).
     * @param center The center of the circle.
     * @param radius The radius of the circle.
     * @param perpendicularVector Vector that is perpendicular to the plane in which the circle shall lie
     *                            and thus defines the orientation of the 2D circle in 3D space.
     *                            If null the circle will lie in the x-y plane, i.e. will not be rotated.
     *                            If not null it must be an array of length 3.
     * @param colors The color(s) of the spheres.
     * @param animationDuration If > 0 the placement is animated and takes 'animationDuration' seconds.
     * @return The spheres or null if one of the parameters is not valid.
     */

    public static GLShapeCV[] makeSpheresOnCircle(int numberOfSpheres, float scalingFactor, float center[], float radius, float[] perpendicularVector, float[][] colors, int animationDuration) {
        if (center==null||center.length!=3||radius<=0||numberOfSpheres<2||scalingFactor<=0) return null;
        long start = (new Date()).getTime();
        GLShapeCV spheres[] = new GLShapeCV[numberOfSpheres];
        float[][] positions = GraphicsUtilsCV.pointsOnCircle3D(center,radius,perpendicularVector,numberOfSpheres);
        for (int i=0; i<numberOfSpheres; i++) {
            if (i==0)
                spheres[i] = GLShapeFactoryCV.makeSphere("Sphere"+i, colors);
            else
                spheres[i] = spheres[0].copy("Sphere"+i);
            if (spheres[i]==null) return null;
            spheres[i].setScale(scalingFactor);
            if (animationDuration>0)
                GLAnimatorFactoryCV.addAnimatorTrans(spheres[i], positions[i], animationDuration, 0);
            else
                spheres[i].setTrans(positions[i]);
        }
        long duration = (new Date()).getTime() - start;
        Log.v("GLDEMO",numberOfSpheres+" spheres: "+duration+" ms");
        return spheres;
    }

    // makeWireframe  (d.h. Tubes zwischen jeweils zwei Punkten)

}
