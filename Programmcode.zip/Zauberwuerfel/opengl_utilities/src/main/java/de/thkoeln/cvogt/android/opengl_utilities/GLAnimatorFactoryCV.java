// This work is provided under GPLv3, the GNU General Public License 3
//   http://www.gnu.org/licenses/gpl-3.0.html

// Prof. Dr. Carsten Vogt
// Technische Hochschule Köln, Germany
// Fakultät für Informations-, Medien- und Elektrotechnik
// carsten.vogt@th-koeln.de
// 11.4.2022

package de.thkoeln.cvogt.android.opengl_utilities;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.TypeEvaluator;
import android.animation.ValueAnimator;
import android.opengl.Matrix;

import java.util.ArrayList;

/**
 * Class with static methods to easily create animators for shapes. It is still rather rudimentary.
 * <BR>
 * An animator returned by the methods of this class can be added to a shape, i.e. an object of class GLShapeCV, through its method addAnimator().
 * The animator will be started automatically when the shape is assigned to a surface view, i.e. an object of class GLSurfaceViewCV, through its method addShape()
 * and then controlled by the renderer of the surface view.
 * <BR>
 * All methods of the Android Java class ObjectAnimator can be applied to the animators, e.g. setInterpolator() to assign a time interpolator to control the timing of the animator.
 *
 * @see GLShapeCV
 */

// TODO WEITERE ANIMATOREN - SIEHE DAZU AUCH METHODEN ADDXXXANIMATOR DER KLASSE ANIMATORGUIOBJECTCV IM PROJEKT UTILITIESPROPANIMCV

public class GLAnimatorFactoryCV {

    /**
     * Makes an animator to scale the shape in the x dimension.
     * Adds the new animator to the animators of the given shape.
     *
     * @param shape       The shape to animate.
     * @param scaleFactor The target scale factor of the animation.
     * @param duration    The duration of the animation.
     * @param repeatCount The number of times the animation shall be repeated.
     * @param reverse     true if the animation shall be reversed.
     * @return The newly generated animator.
     */

    public static ObjectAnimator addAnimatorScaleX(GLShapeCV shape, float scaleFactor, int duration, int repeatCount, boolean reverse) {
        ObjectAnimator animator = ObjectAnimator.ofFloat(shape, "scaleX", scaleFactor);
        animator.setDuration(duration);
        animator.setRepeatCount(repeatCount);
        if (reverse)
            animator.setRepeatMode(ValueAnimator.REVERSE);
        shape.addAnimator(animator);
        return animator;
    }

    /**
     * Makes an animator to scale the shape in the y dimension.
     * Adds the new animator to the animators of the given shape.
     *
     * @param shape       The shape to animate.
     * @param scaleFactor The target scale factor of the animation.
     * @param duration    The duration of the animation.
     * @param repeatCount The number of times the animation shall be repeated.
     * @param reverse     true if the animation shall be reversed.
     * @return The newly generated animator.
     */

    public static ObjectAnimator addAnimatorScaleY(GLShapeCV shape, float scaleFactor, int duration, int repeatCount, boolean reverse) {
        ObjectAnimator animator = ObjectAnimator.ofFloat(shape, "scaleY", scaleFactor);
        animator.setDuration(duration);
        animator.setRepeatCount(repeatCount);
        if (reverse)
            animator.setRepeatMode(ValueAnimator.REVERSE);
        shape.addAnimator(animator);
        return animator;
    }

    /**
     * Makes an animator to scale the shape in the z dimension.
     * Adds the new animator to the animators of the given shape.
     *
     * @param shape       The shape to animate.
     * @param scaleFactor The target scale factor of the animation.
     * @param duration    The duration of the animation.
     * @param repeatCount The number of times the animation shall be repeated.
     * @param reverse     true if the animation shall be reversed.
     * @return The newly generated animator.
     */

    public static ObjectAnimator addAnimatorScaleZ(GLShapeCV shape, float scaleFactor, int duration, int repeatCount, boolean reverse) {
        ObjectAnimator animator = ObjectAnimator.ofFloat(shape, "scaleZ", scaleFactor);
        animator.setDuration(duration);
        animator.setRepeatCount(repeatCount);
        if (reverse)
            animator.setRepeatMode(ValueAnimator.REVERSE);
        shape.addAnimator(animator);
        return animator;
    }

    /**
     * Makes an animator to let the shape make a rotation around its x axis.
     * Adds the new animator to the animators of the given shape.
     *
     * @param shape           The shape to animate.
     * @param angleToTraverse The rotation angle to traverse.
     * @param duration        The duration of the animation.
     * @param repeatCount     The number of times the animation shall be repeated.
     * @param reverse         true if the animation shall be reversed.
     * @return The newly generated animator.
     */

    public static ObjectAnimator addAnimatorRotX(GLShapeCV shape, float angleToTraverse, int duration, int repeatCount, boolean reverse) {
        float axis[] = {1, 0, 0};
        return GLAnimatorFactoryCV.addAnimatorRot(shape, angleToTraverse, axis, duration, repeatCount, reverse);
    }

    /**
     * Makes an animator to let the shape make a rotation around its y axis.
     * Adds the new animator to the animators of the given shape.
     *
     * @param shape           The shape to animate.
     * @param angleToTraverse The rotation angle to traverse.
     * @param duration        The duration of the animation.
     * @param repeatCount     The number of times the animation shall be repeated.
     * @param reverse         true if the animation shall be reversed.
     * @return The newly generated animator.
     */

    public static ObjectAnimator addAnimatorRotY(GLShapeCV shape, float angleToTraverse, int duration, int repeatCount, boolean reverse) {
        float axis[] = {0, 1, 0};
        return GLAnimatorFactoryCV.addAnimatorRot(shape, angleToTraverse, axis, duration, repeatCount, reverse);
    }

    /**
     * Makes an animator to let the shape make a rotation around its z axis.
     * Adds the new animator to the animators of the given shape.
     *
     * @param shape           The shape to animate.
     * @param angleToTraverse The rotation angle to traverse.
     * @param duration        The duration of the animation.
     * @param repeatCount     The number of times the animation shall be repeated.
     * @param reverse         true if the animation shall be reversed.
     * @return The newly generated animator.
     */

    public static ObjectAnimator addAnimatorRotZ(GLShapeCV shape, float angleToTraverse, int duration, int repeatCount, boolean reverse) {
        float axis[] = {0, 0, 1};
        return GLAnimatorFactoryCV.addAnimatorRot(shape, angleToTraverse, axis, duration, repeatCount, reverse);
    }

    /**
     * Makes an animator to let the shape make a rotation a specified axis.
     * Adds the new animator to the animators of the given shape.
     *
     * @param shape           The shape to animate.
     * @param angleToTraverse The rotation angle to traverse.
     * @param axis            The rotation axis.
     * @param duration        The duration of the animation.
     * @param repeatCount     The number of times the animation shall be repeated.
     * @param reverse         true if the animation shall be reversed.
     * @return The newly generated animator.
     */

    public static ObjectAnimator addAnimatorRot(GLShapeCV shape, float angleToTraverse, float[] axis, int duration, int repeatCount, boolean reverse) {
        EvaluatorRotation eval = new EvaluatorRotation(shape, angleToTraverse, axis);
        float[] dummy = new float[4];
        ObjectAnimator animator = ObjectAnimator.ofObject(shape, "rotationForAnimator", eval, dummy, dummy);
        animator.setDuration(duration);
        animator.setRepeatCount(repeatCount);
        if (reverse)
            animator.setRepeatMode(ValueAnimator.REVERSE);
        shape.addAnimator(animator);
        return animator;
    }

    /**
     * Class that defines a TypeEvaluator for a rotation around an axis - see method addAnimatorRot().
     */

    private static class EvaluatorRotation implements TypeEvaluator<float[]> {
        private GLShapeCV shape;
        private float[] startRotMatrix; // rotation matrix of the shape when the rotation starts
        private float angleToTraverse;  // rotation angle to traverse in the animation
        private float[] axis;           // rotation axis of the animation
        private boolean attributeIsValid;

        EvaluatorRotation(GLShapeCV shape, float angleToTraverse, float[] axis) {
            this.shape = shape;
            this.angleToTraverse = angleToTraverse;
            this.axis = axis.clone();
            this.attributeIsValid = false;
        }

        public float[] evaluate(float f, float[] dummy1, float[] dummy2) {
            if (!attributeIsValid) {
                startRotMatrix = shape.getRotationMatrix();
                attributeIsValid = true;
            }
            float currentRotAngle = f * angleToTraverse;
            float[] rotMatrix = new float[16];
            Matrix.setRotateM(rotMatrix, 0, currentRotAngle, axis[0], axis[1], axis[2]);
            Matrix.multiplyMM(rotMatrix, 0, rotMatrix, 0, startRotMatrix, 0);
            float[] result = new float[4];
            // TODO More efficient programming: The following methods are not very efficient (e.g. repeated checks if the matrix is indeed a rotation matrix)
            float[][] rotMatrix2Dim = GraphicsUtilsCV.matrixFromArray(rotMatrix, 4, 4);
            result[0] = GraphicsUtilsCV.rotAngleFrom4x4RotationMatrix(rotMatrix2Dim);
            float[] tmp = GraphicsUtilsCV.rotAxisFrom4x4RotationMatrix(rotMatrix2Dim);
            result[1] = tmp[0];
            result[2] = tmp[1];
            result[3] = tmp[2];
            return result;
        }

    }

    /**
     * Makes an animator to let the shape move to a specific x position.
     * Adds the new animator to the animators of the given shape.
     *
     * @param shape       The shape to animate.
     * @param targetX     The target x position of the animation.
     * @param duration    The duration of the animation.
     * @param repeatCount The number of times the animation shall be repeated. If repeatCount is greater than 1, the animation is reversed.
     * @return The newly generated animator.
     */

    public static ObjectAnimator addAnimatorTransX(GLShapeCV shape, float targetX, int duration, int repeatCount) {
        ObjectAnimator animator = ObjectAnimator.ofFloat(shape, "transX", targetX);
        animator.setDuration(duration);
        animator.setRepeatCount(repeatCount);
        animator.setRepeatMode(ValueAnimator.REVERSE);
        shape.addAnimator(animator);
        return animator;
    }

    /**
     * Makes an animator to let the shape move to a specific y position.
     * Adds the new animator to the animators of the given shape.
     *
     * @param shape       The shape to animate.
     * @param targetY     The target y position of the animation.
     * @param duration    The duration of the animation.
     * @param repeatCount The number of times the animation shall be repeated. If repeatCount is greater than 1, the animation is reversed.
     * @return The newly generated animator.
     */

    public static ObjectAnimator addAnimatorTransY(GLShapeCV shape, float targetY, int duration, int repeatCount) {
        ObjectAnimator animator = ObjectAnimator.ofFloat(shape, "transY", targetY);
        animator.setDuration(duration);
        animator.setRepeatCount(repeatCount);
        animator.setRepeatMode(ValueAnimator.REVERSE);
        shape.addAnimator(animator);
        return animator;
    }

    /**
     * Makes an animator to let the shape move to a specific z position.
     * Adds the new animator to the animators of the given shape.
     *
     * @param shape       The shape to animate.
     * @param targetZ     The target z position of the animation.
     * @param duration    The duration of the animation.
     * @param repeatCount The number of times the animation shall be repeated. If repeatCount is greater than 1, the animation is reversed.
     * @return The newly generated animator.
     */

    public static ObjectAnimator addAnimatorTransZ(GLShapeCV shape, float targetZ, int duration, int repeatCount) {
        ObjectAnimator animator = ObjectAnimator.ofFloat(shape, "transZ", targetZ);
        animator.setDuration(duration);
        animator.setRepeatCount(repeatCount);
        animator.setRepeatMode(ValueAnimator.REVERSE);
        shape.addAnimator(animator);
        return animator;
    }

    /**
     * Makes an animator to let the shape move to a specific (x,y,z) position.
     * Adds the new animator to the animators of the given shape.
     *
     * @param shape       The shape to animate.
     * @param targetX     The target x position of the animation.
     * @param targetY     The target y position of the animation.
     * @param targetZ     The target z position of the animation.
     * @param duration    The duration of the animation.
     * @param repeatCount The number of times the animation shall be repeated. If repeatCount is greater than 1, the animation is reversed.
     * @return The newly generated animator.
     */

    public static ObjectAnimator addAnimatorTrans(GLShapeCV shape, float targetX, float targetY, float targetZ, int duration, int repeatCount) {
        ObjectAnimator animator = ObjectAnimator.ofPropertyValuesHolder(shape, PropertyValuesHolder.ofFloat("transX", targetX),
                PropertyValuesHolder.ofFloat("transY", targetY), PropertyValuesHolder.ofFloat("transZ", targetZ));
        animator.setDuration(duration);
        animator.setRepeatCount(repeatCount);
        animator.setRepeatMode(ValueAnimator.REVERSE);
        shape.addAnimator(animator);
        return animator;
    }

    /**
     * Makes an animator to let the shape move to a specific (x,y,z) position.
     * Adds the new animator to the animators of the given shape.
     *
     * @param shape       The shape to animate.
     * @param target      The target  position of the animation.
     * @param duration    The duration of the animation.
     * @param repeatCount The number of times the animation shall be repeated. If repeatCount is greater than 1, the animation is reversed.
     * @return The newly generated animator or null if the target parameter is not valid, i.e. not an array of length 3.
     */

    public static ObjectAnimator addAnimatorTrans(GLShapeCV shape, float[] target, int duration, int repeatCount) {
        if (target == null || target.length != 3) return null;
        return addAnimatorTrans(shape, target[0], target[1], target[2], duration, repeatCount);
    }

    /**
     * Makes animators to place a shape between two given points, i.e. to translate and to rotate it and (optionally) to scale it.
     * The y axis of the object is rotated, i.e. will afterwards be in line with the two points.
     * Adds the new animators to the animators of the shape.
     *
     * @param shape    The shape to animate.
     * @param point1   The first point.
     * @param point1   The second point.
     * @param scaleX   The target scaling factor for the x dimension.
     * @param scaleY   The target scaling factor for the y dimension.
     * @param scaleZ   The target scaling factor for the z dimension.
     * @param duration The duration of the animation.
     * @return An ArrayList with the animators.
     */

    public static ArrayList<ObjectAnimator> addAnimatorPlaceBetween(GLShapeCV shape, float[] point1, float[] point2, float scaleX, float scaleY, float scaleZ, int duration) {
        if (point1 == null || point1.length != 3 || point2 == null || point2.length != 3 || Math.abs(shape.getIntrinsicSizeY()) < 1E-5)
            return null;
        float y_axis[] = {0, 1, 0};
        float[] midpoint = GraphicsUtilsCV.midpoint(point1, point2);
        float vectorBetweenPoints[] = GraphicsUtilsCV.vectorBetweenPoints(point1, point2);
        /* Lösung mit ofMultiFloat(), die aber nicht funktioniert
        ObjectAnimator animator;
        // Log.v("GLDEMO","addAnimatorPlaceBetween for "+shape.getId());
        if (Math.abs(vectorBetweenPoints[0])>10e-5||Math.abs(vectorBetweenPoints[2])>10e-5) {
            // rotate only if the rotation axis is not parallel to the y axis
            float rotAxis[] = GraphicsUtilsCV.crossProduct(y_axis, vectorBetweenPoints);
            float rotAngle = (float) Math.toDegrees(Math.acos(GraphicsUtilsCV.dotProduct(y_axis, GraphicsUtilsCV.getNormalizedCopy(GraphicsUtilsCV.vectorBetweenPoints(point1, point2)))));
            float[][] animatorRotParam = new float[2][4];
            animatorRotParam[0][0] = shape.getRotAngle();
            // Log.v("GLDEMO","start angle: "+animatorRotParam[0][0]);
            animatorRotParam[1][0] = shape.getRotAngle()+rotAngle;
            // Log.v("GLDEMO","target angle: "+animatorRotParam[1][0]);
            animatorRotParam[0][1] = animatorRotParam[1][1] = rotAxis[0];
            animatorRotParam[0][2] = animatorRotParam[1][2] = rotAxis[1];
            animatorRotParam[0][3] = animatorRotParam[1][3] = rotAxis[2];
            animator = ObjectAnimator.ofPropertyValuesHolder(shape,
                    PropertyValuesHolder.ofFloat("scaleX", scaleX),
                    PropertyValuesHolder.ofFloat("scaleY", scaleY),
                    PropertyValuesHolder.ofFloat("scaleZ", scaleZ),
                    // bug: setRotationForAnimator() is not called.
                    PropertyValuesHolder.ofMultiFloat("rotationForAnimator", animatorRotParam),
                    PropertyValuesHolder.ofFloat("transX", midpoint[0]),
                    PropertyValuesHolder.ofFloat("transY", midpoint[1]),
                    PropertyValuesHolder.ofFloat("transZ", midpoint[2]));
        } else {
            // Log.v("GLDEMO","addAnimatorPlaceBetween for "+shape.getId()+" - else");
            animator = ObjectAnimator.ofPropertyValuesHolder(shape,
                    PropertyValuesHolder.ofFloat("scaleX", scaleX),
                    PropertyValuesHolder.ofFloat("scaleY", scaleY),
                    PropertyValuesHolder.ofFloat("scaleZ", scaleZ),
                    PropertyValuesHolder.ofFloat("transX", midpoint[0]),
                    PropertyValuesHolder.ofFloat("transY", midpoint[1]),
                    PropertyValuesHolder.ofFloat("transZ", midpoint[2]));
        }
        animator.setDuration(duration);
        shape.addAnimator(animator);
        return animator;
        */
        /* Alternativ: Einzelanimatoren */
        ArrayList<ObjectAnimator> animators = new ArrayList<>();
        if (Math.abs(vectorBetweenPoints[0]) > 10e-5 || Math.abs(vectorBetweenPoints[2]) > 10e-5) {
            // rotate only if the rotation axis is not parallel to the y axis
            float rotAxisForShape[] = GraphicsUtilsCV.crossProduct(y_axis, vectorBetweenPoints);
            float rotAngleForShape = (float) Math.toDegrees(Math.acos(GraphicsUtilsCV.dotProduct(y_axis, GraphicsUtilsCV.getNormalizedCopy(GraphicsUtilsCV.vectorBetweenPoints(point1, point2)))));
            shape.setRotAxis(rotAxisForShape);
            animators.add(GLAnimatorFactoryCV.addAnimatorRot(shape, rotAngleForShape, rotAxisForShape, duration, 0, false));
        }
        animators.add(GLAnimatorFactoryCV.addAnimatorScaleX(shape, scaleX, duration, 0, false));
        animators.add(GLAnimatorFactoryCV.addAnimatorScaleY(shape, scaleY, duration, 0, false));
        animators.add(GLAnimatorFactoryCV.addAnimatorScaleZ(shape, scaleZ, duration, 0, false));
        animators.add(GLAnimatorFactoryCV.addAnimatorTrans(shape, midpoint, duration, 0));
        return animators;
    }

    /**
     * Makes an animator to move the shape in a plane with constant z (i.e. a vertical plane) along an arc around a specified center.
     * Adds the new animator to the animators of the given shape.
     *
     * @param centerCircleX The x coordinate of the circle center.
     * @param centerCircleY The y coordinate of the circle center.
     * @param angle         The angle of the arc to be traversed.
     * @param clockwise     Movement clockwise or anticlockwise?
     * @param duration      The duration of the animation (in ms).
     * @param startDelay    The start delay of the animation (in ms).
     * @return The new animator
     */

    public static ObjectAnimator addAnimatorArcPathInVerticalPlane(GLShapeCV shape, float centerCircleX, float centerCircleY, float angle, boolean clockwise, int duration, int startDelay) {
        if (clockwise) angle = -angle;
        float[] center = new float[3];
        center[0] = centerCircleX;
        center[1] = centerCircleY;
        center[2] = shape.getTransZ();
        EvaluatorArcPathInVerticalPlane eval = new EvaluatorArcPathInVerticalPlane(shape, center, angle);
        float[] dummy = new float[3];
        ObjectAnimator anim = ObjectAnimator.ofObject(shape, "trans", eval, dummy, dummy);
        anim.setDuration(duration);
        anim.setStartDelay(startDelay);
        shape.addAnimator(anim);
        return anim;
    }

    /**
     * Class that defines a TypeEvaluator for a movement along an arc in a vertical plane - see method addAnimatorArcPathInVerticalPlane().
     */

    private static class EvaluatorArcPathInVerticalPlane implements TypeEvaluator<float[]> {
        GLShapeCV shape;  // shape to be animated
        float[] center;  // center of the circle - same z value as the shape
        double angle;  // angle of the arc to traverse
        float[] start;  // start position of the shape
        boolean attributeIsValid;

        // The start position of the animated shape is stored when the animation starts.
        // 'attributeIsValid' specifies if this has been done already.
        EvaluatorArcPathInVerticalPlane(GLShapeCV shape, float[] center, double angle) {
            this.shape = shape;
            this.center = center.clone();
            this.angle = angle;
            this.attributeIsValid = false;
        }

        public float[] evaluate(float f, float dummy1[], float[] dummy2) {
            if (!attributeIsValid) {
                start = shape.getTrans();
                attributeIsValid = true;
            }
            float[] retval = new float[3];
            retval[0] = center[0] + (float) ((start[0] - center[0]) * Math.cos(f * angle * Math.PI / 180) - (start[1] - center[1]) * Math.sin(f * angle * Math.PI / 180));
            retval[1] = center[1] + (float) ((start[0] - center[0]) * Math.sin(f * angle * Math.PI / 180) + (start[1] - center[1]) * Math.cos(f * angle * Math.PI / 180));
            retval[2] = start[2];
            return retval;
        }

    }

    /**
     * Makes an animator to move the shape along an arc around an axis that is specified by two points in 3D space.
     * Adds the new animator to the animators of the given shape.
     *
     * @param axisPoint1 The first point defining the axis.
     * @param axisPoint2 The second point defining the axis.
     * @param angle      The angle of the arc to be traversed.
     * @param clockwise  Movement clockwise or anticlockwise?
     * @param duration   The duration of the animation (in ms).
     * @param startDelay The start delay of the animation (in ms).
     * @return The new animator
     */

    public static ObjectAnimator addAnimatorArcPathAroundAxis(GLShapeCV shape, float[] axisPoint1, float[] axisPoint2, float angle, boolean clockwise, int duration, int startDelay) {
        if (clockwise) angle = -angle;
        EvaluatorArcPathAroundAxis eval = new EvaluatorArcPathAroundAxis(shape, axisPoint1, axisPoint2, angle);
        float[] dummy = new float[3];
        ObjectAnimator anim = ObjectAnimator.ofObject(shape, "trans", eval, dummy, dummy);
        anim.setDuration(duration);
        anim.setStartDelay(startDelay);
        shape.addAnimator(anim);
        return anim;
    }

    /**
     * Class that defines a TypeEvaluator for a movement along an arc around an axis - see method addAnimatorArcPathAroundAxis().
     */

    private static class EvaluatorArcPathAroundAxis implements TypeEvaluator<float[]> {
        GLShapeCV shape;  // shape to be animated
        float[] axisPoint1;  // first point on the axis
        float[] axisPoint2;  // second point on the axis
        double angle;  // angle of the arc to traverse
        float[] start;  // start position of the shape
        boolean attributeIsValid;

        // The start position of the animated shape is stored when the animation starts.
        // 'attributeIsValid' specifies if this has been done already.
        EvaluatorArcPathAroundAxis(GLShapeCV shape, float[] axisPoint1, float[] axisPoint2, double angle) {
            this.shape = shape;
            this.axisPoint1 = axisPoint1.clone();
            this.axisPoint2 = axisPoint2.clone();
            this.angle = angle;
            this.attributeIsValid = false;
        }

        public float[] evaluate(float f, float dummy1[], float[] dummy2) {
            if (!attributeIsValid) {
                start = shape.getTrans();
                attributeIsValid = true;
            }
            float[] retval = GraphicsUtilsCV.rotateAroundAxis(start, axisPoint1, axisPoint2, (float) (f * angle));
            return retval;
        }

    }

    /**
     * Makes an animator to move the shape in a spiral around a specified center.
     * The spiral is centered around a vertical line that goes through a "spiral center" with given x and z coordinates.
     * Adds the new animator to the animators of the given shape.
     *
     * @param centerSpiralX The x coordinate of the circle center
     * @param centerSpiralZ The z coordinate of the circle center
     * @param height        The height of the spiral, i.e. the maximum y to be reached
     * @param noTurns       The number of turns of the spiral.
     * @param clockwise     Spiral clockwise or anticlockwise?
     * @param duration      The duration of the animation (in ms)
     * @param startDelay    The start delay of the animation (in ms)
     * @return The new animator
     */

    public static ObjectAnimator addAnimatorSpiralPath(GLShapeCV shape, float centerSpiralX, float centerSpiralZ, float height, int noTurns, boolean clockwise, int duration, int startDelay) {
        float angle = noTurns * 360f;
        if (!clockwise) angle = -angle;
        float[] center = new float[3];
        center[0] = centerSpiralX;
        center[1] = shape.getTransY();
        center[2] = centerSpiralZ;
        EvaluatorSpiralPath eval = new EvaluatorSpiralPath(shape, center, height, angle);
        float[] dummy = new float[3];
        ObjectAnimator anim = ObjectAnimator.ofObject(shape, "trans", eval, dummy, dummy);
        anim.setDuration(duration);
        anim.setStartDelay(startDelay);
        shape.addAnimator(anim);
        return anim;
    }

    /**
     * Class that defines a TypeEvaluator for a movement along a spiral - see method addAnimatorSpiralPath().
     */

    private static class EvaluatorSpiralPath implements TypeEvaluator<float[]> {

        GLShapeCV shape;  // shape to be animated
        float[] center;   // center of the spiral - the same y value as the initial y value of the shape
        float[] start;    // start position of the shape
        float height;     // height of the spiral to traverse
        float angle;      // angle of the spiral to traverse
        boolean attributeIsValid;

        // The start position of the animated shape is stored when the animation starts.
        // 'attributeIsValid' specifies if this has been done already.
        EvaluatorSpiralPath(GLShapeCV shape, float[] center, float height, float angle) {
            this.shape = shape;
            this.center = center.clone();
            this.height = height;
            this.angle = angle;
            this.attributeIsValid = false;
        }

        public float[] evaluate(float f, float dummy1[], float[] dummy2) {
            if (!attributeIsValid) {
                start = shape.getTrans();
                attributeIsValid = true;
            }
            float[] retval = new float[3];
            retval[0] = center[0] + (float) ((start[0] - center[0]) * Math.cos(f * angle * Math.PI / 180) - (start[2] - center[2]) * Math.sin(f * angle * Math.PI / 180));
            retval[1] = start[1] + f * height;
            retval[2] = center[2] + (float) ((start[0] - center[0]) * Math.sin(f * angle * Math.PI / 180) + (start[2] - center[2]) * Math.cos(f * angle * Math.PI / 180));
            return retval;
        }

    }

    /**
     * Class for listeners that shall be executed when an animation ends
     * and that will remove the animated shape from the surface view.
     */

    public static class EndListenerRemove extends AnimatorListenerAdapter {
        private GLShapeCV shape;
        private GLSurfaceViewCV surfaceView;

        public EndListenerRemove(GLShapeCV shape, GLSurfaceViewCV surfaceView) {
            this.shape = shape;
            this.surfaceView = surfaceView;
        }

        @Override
        public void onAnimationEnd(Animator animator) {
            surfaceView.removeShape(shape);
        }
    }

  /*
    public static ObjectAnimator makeAnimatorTrans(GLShapeCV shape, float[] transStart, float[] transEnd, int duration, int repeatCount) {

        // MIT ofMultiFloat FUNKTIONIERT ES NICHT: DER LISTENER RUFT DIE METHODE setTrans() NICHT AUF

        // Log.v("DEMO","makeAnimatorTrans: "+transStart[0]+" "+transStart[1]+" "+transStart[2]+" "+transEnd[0]+" "+transEnd[1]+" "+transEnd[2]);

        float startEnd[][] = new float[2][];
        startEnd[0] = transStart;
        startEnd[1] = transEnd;
        // ObjectAnimator animator = ObjectAnimator.ofMultiFloat(shape, "trans", startEnd);

        ObjectAnimator animator = ObjectAnimator.ofPropertyValuesHolder(shape,PropertyValuesHolder.ofFloat("transX",2),
                PropertyValuesHolder.ofFloat("transY",10),PropertyValuesHolder.ofFloat("transZ",-10));

        // ObjectAnimator animator = ObjectAnimator.ofPropertyValuesHolder(shape,PropertyValuesHolder.ofFloat("transZ",-4));
        animator.setDuration(duration);

        // animator.setRepeatCount(repeatCount);
        // animator.setRepeatMode(ValueAnimator.REVERSE);
        // Log.v("DEMO","makeAnimatorTrans: "+startEnd[0][0]+" "+startEnd[0][1]+" "+startEnd[0][2]+"  "+startEnd[1][0]+" "+startEnd[1][1]+" "+startEnd[1][2]+" ");
        return animator;
    }

   */

}
